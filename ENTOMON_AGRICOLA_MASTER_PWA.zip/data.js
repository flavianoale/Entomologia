
const ORDENS = {
Coleoptera:["Curculionidae","Chrysomelidae","Scarabaeidae","Carabidae"],
Lepidoptera:["Noctuidae","Pyralidae","Geometridae","Tortricidae"],
Hemiptera:["Pentatomidae","Aphididae","Cicadellidae","Reduviidae"],
Diptera:["Tephritidae","Culicidae","Muscidae"],
Hymenoptera:["Formicidae","Braconidae","Apidae","Ichneumonidae"],
Orthoptera:["Acrididae","Gryllidae"]
};

const MORFOLOGIA = [
"Clípeo","Labro","Mandíbulas","Maxilas","Lábio",
"Antena filiforme","Antena geniculada","Élitro",
"Hemélitro","Halteres","Pronoto","Mesonoto",
"Metanoto","Coxa","Trocânter","Fêmur","Tíbia","Tarso"
];
